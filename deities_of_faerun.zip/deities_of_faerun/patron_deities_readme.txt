Patron Deities
by 
Johnathan Crow (Mod Author)
AnaxXiphos (Decision Icon Graphics)
Flo (French Localisation)
omega20056 (Yazidi Patrons)

A. Manual Installation
	1. Delete old versions, just in case
	2. Extract the folder and .mod file to 'Documents\Paradox Interactive\Crusader Kings II\mod'

B. Historical Immersion Pack Patch
	1. Go to 'Documents\Paradox Interactive\Crusader Kings II\mod\patron_deities\patches'
	2. Select 'emf' if using any HIP set-up that includes the EMF module
	3. Copy the decisions folder to 'Documents\Paradox Interactive\Crusader Kings II\mod\patron_deities'
	3. Merge folders, then select 'Copy and Replace' when prompted
	4. Open 'Documents\Paradox Interactive\Crusader Kings II\mod\patron_deities.mod' with a text editor
	6. Remove the hashtag (#) before "HIP - Historical Immersion Project" (if you have a custom installation folder name, rename it to that)
	7. Save and exit
	
Note: You only need to apply a patch for the EMF module of HIP.